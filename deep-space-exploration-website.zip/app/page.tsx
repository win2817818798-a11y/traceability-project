"use client"

import Navigation from "@/components/navigation"
import Hero from "@/components/hero"
import ValueProposition from "@/components/value-proposition"
import Ecosystem from "@/components/ecosystem"
import Footer from "@/components/footer"
import StarField from "@/components/star-field"

export default function Home() {
  return (
    <main className="relative">
      {/* Background starfield */}
      <StarField />

      {/* Content with proper z-indexing */}
      <div className="relative z-10">
        <Navigation />
        <Hero />
        <ValueProposition />
        <Ecosystem />
        <Footer />
      </div>
    </main>
  )
}
