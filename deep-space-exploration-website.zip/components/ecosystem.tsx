"use client"

const ecosystemItems = [
  {
    id: 1,
    title: "Ground Research Stations",
    description: "Advanced command centers providing real-time monitoring and analysis",
    image: "/futuristic-ground-research-facility-with-advanced-.jpg",
  },
  {
    id: 2,
    title: "Accompanying Flying Vehicles",
    description: "Autonomous spacecraft designed for deep space exploration missions",
    image: "/sleek-spacecraft-in-deep-space-with-blue-and-orang.jpg",
  },
  {
    id: 3,
    title: "Integrated Systems",
    description: "Seamless communication and control networks across all platforms",
    image: "/digital-network-visualization-with-connected-syste.jpg",
  },
]

export default function Ecosystem() {
  return (
    <section id="ecosystem" className="relative py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">Our Ecosystem</h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Integrated components working together to push the boundaries of space exploration
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {ecosystemItems.map((item) => (
            <div
              key={item.id}
              className="group relative overflow-hidden rounded-lg border border-border hover:border-accent/50 transition-all duration-300"
            >
              {/* Image Container */}
              <div className="relative h-64 overflow-hidden bg-secondary/20">
                <img
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>

              {/* Content */}
              <div className="p-6 bg-card/80 backdrop-blur-sm">
                <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                <p className="text-foreground/70">{item.description}</p>
                <div className="mt-4 flex items-center text-accent group-hover:translate-x-1 transition-transform">
                  <span className="text-sm font-semibold">Learn More</span>
                  <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
