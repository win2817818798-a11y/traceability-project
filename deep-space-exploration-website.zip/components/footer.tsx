"use client"

import { Mail, MapPin, Phone } from "lucide-react"

export default function Footer() {
  return (
    <footer className="relative border-t border-border bg-card/30 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <div className="w-4 h-4 border-2 border-white rounded-full"></div>
              </div>
              <span className="text-lg font-bold text-white">Deep Space</span>
            </div>
            <p className="text-foreground/60 text-sm">
              Redefining the boundaries of deep space exploration through innovation and determination.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {["Home", "Traceability Plan", "Ecosystem", "Careers"].map((link) => (
                <li key={link}>
                  <a href="#" className="text-foreground/60 hover:text-accent text-sm transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-white font-semibold mb-4">Resources</h4>
            <ul className="space-y-2">
              {["Documentation", "Research", "Blog", "Support"].map((link) => (
                <li key={link}>
                  <a href="#" className="text-foreground/60 hover:text-accent text-sm transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contact</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-2 text-sm text-foreground/60 hover:text-accent transition-colors cursor-pointer">
                <Mail size={16} className="mt-1 flex-shrink-0" />
                <span>contact@deepspace.com</span>
              </div>
              <div className="flex items-start gap-2 text-sm text-foreground/60 hover:text-accent transition-colors cursor-pointer">
                <Phone size={16} className="mt-1 flex-shrink-0" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-start gap-2 text-sm text-foreground/60 hover:text-accent transition-colors cursor-pointer">
                <MapPin size={16} className="mt-1 flex-shrink-0" />
                <span>Space Research Hub, Earth Orbit</span>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-border mb-8" />

        {/* Bottom */}
        <div className="flex flex-col md:flex-row justify-between items-center text-sm text-foreground/60">
          <p>&copy; 2025 Deep Space Exploration Company. All rights reserved.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-accent transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-accent transition-colors">
              Terms of Service
            </a>
            <a href="#" className="hover:text-accent transition-colors">
              Sitemap
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
