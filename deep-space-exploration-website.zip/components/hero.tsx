"use client"

import { useState } from "react"
import { Play, ArrowRight } from "lucide-react"

export default function Hero() {
  const [isVideoOpen, setIsVideoOpen] = useState(false)

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-16 px-4">
      <div
        className="absolute inset-0 bg-gradient-to-b from-primary/10 to-transparent"
        style={{
          background: "linear-gradient(135deg, rgba(30, 64, 175, 0.15) 0%, rgba(255, 140, 66, 0.05) 100%)",
        }}
      />

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* Main Title */}
        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight text-balance">
          Traceability Plan:{" "}
          <span className="bg-gradient-to-r from-accent to-orange-400 bg-clip-text text-transparent">
            Redefining Deep Space Exploration
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg sm:text-xl text-foreground/80 mb-12 max-w-3xl mx-auto text-balance">
          <span className="text-accent font-semibold">Cutting-edge Research</span>
          {" · "}
          <span className="text-accent font-semibold">Personal Maneuverability</span>
          {" · "}
          <span className="text-accent font-semibold">System Integration</span>
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="px-8 py-4 bg-gradient-to-r from-primary to-blue-600 text-white font-semibold rounded-lg hover:shadow-lg hover:shadow-primary/50 transition-all duration-300 flex items-center justify-center gap-2 group">
            Explore the Plan
            <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </button>
          <button
            onClick={() => setIsVideoOpen(true)}
            className="px-8 py-4 border-2 border-accent text-accent font-semibold rounded-lg hover:bg-accent/10 transition-colors flex items-center justify-center gap-2"
          >
            <Play size={20} />
            Watch the Video
          </button>
        </div>

        {/* Video Modal */}
        {isVideoOpen && (
          <div
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setIsVideoOpen(false)}
          >
            <div
              className="relative w-full max-w-4xl aspect-video rounded-lg overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-full h-full bg-secondary/20 flex items-center justify-center">
                <div className="text-center">
                  <Play size={64} className="text-accent mx-auto mb-4" />
                  <p className="text-white text-lg">Video placeholder - Replace with actual video</p>
                </div>
              </div>
              <button
                onClick={() => setIsVideoOpen(false)}
                className="absolute top-4 right-4 bg-black/50 hover:bg-black text-white p-2 rounded-full transition-colors"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-accent rounded-full flex justify-center">
            <div className="w-1 h-2 bg-accent rounded-full mt-2" />
          </div>
        </div>
      </div>
    </section>
  )
}
