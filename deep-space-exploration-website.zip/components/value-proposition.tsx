import { Zap, Shield, Heart } from "lucide-react"

const values = [
  {
    icon: Shield,
    title: "Reliability",
    description:
      "Mission-critical systems designed with redundancy and fail-safes to ensure unwavering performance in the harshest space environments.",
  },
  {
    icon: Zap,
    title: "Autonomy",
    description:
      "Advanced AI-driven systems enable independent decision-making and problem-solving capabilities for extended missions beyond Earth.",
  },
  {
    icon: Heart,
    title: "Humanistic Care",
    description:
      "Technology designed with human welfare at the center, prioritizing crew safety, well-being, and long-term psychological health.",
  },
]

export default function ValueProposition() {
  return (
    <section id="advantages" className="relative py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-6">Our Core Values</h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Three pillars that define our approach to deep space exploration
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {values.map((value, index) => {
            const Icon = value.icon
            return (
              <div key={index} className="relative group">
                <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-primary/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur" />

                <div className="relative bg-card/50 backdrop-blur-sm border border-border rounded-lg p-8 hover:border-accent/50 transition-all duration-300">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-accent to-orange-400 flex items-center justify-center mb-4">
                    <Icon size={24} className="text-background" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">{value.title}</h3>
                  <p className="text-foreground/70 leading-relaxed">{value.description}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
